package com.example.myapplication;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class DesignSportActivity extends AppCompatActivity implements LocationListener {
    private String category;
    private LocationManager locationManager;
    private TextView info_sport_category;
    private Button confirm_date;
    private String formattedDate;
    private SimpleDateFormat dateFormat;
    private Button create_sport_activity;
    private String time;
    private String date;
    private String temp;
    private String message;
    private String title;
    private String my_location = "ESTADIO DE GEVIM";
    private EditText editText_title;
    private Calendar calendar;
    private Button getDate;
    private String description;
    private EditText editText_sport_act_desc;
    private SportingActivityClass sportingActivityClass;
    private CustomerDao customerDao;
    private AppDatabase app_db;
    private Button btn_to_see_sport_activities;
    private int hour;
    private int minute;
    private Button view_sport_activities;
    private Button get_location;
    private SportingActivityClassDao sportingActivityClassDao;
    private Customer selected_customer;
    private ViewGroup.LayoutParams originalLayoutParams;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_design_sport);
        Intent intent = getIntent();
        init();
        getDate();
        func_createSportActivity();
        func_expand_cv();
        func_view_sport_activities();
        func_get_location();
    }

    public void func_get_location(){
        get_location = findViewById(R.id.get_location);
        get_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                func_grant_permission();
                setLocationManager();
            }
        });
    }

    public void func_grant_permission(){
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(getApplicationContext(),
                android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION}, 101);
        }
    }

    public void setLocationManager(){
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationEnabled();
        getLocation();
    }

    private void locationEnabled() {
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        boolean gps_enabled = false;
        boolean network_enabled = false;
        try {
            gps_enabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            network_enabled = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (!gps_enabled && !network_enabled) {
            new AlertDialog.Builder(DesignSportActivity.this)
                    .setTitle("אשרו שימוש בGPS")
                    .setMessage("עבור להשתמש בחלק זה צריך להפעילה GPS.")
                    .setCancelable(false)
                    .setPositiveButton("לאשר", new
                            DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface paramDialogInterface, int paramInt) {
                                    startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                                }
                            })
                    .setNegativeButton("לבטל", null)
                    .show();
        }
    }

    void getLocation() {
        try {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 500, 5, this);
            Location location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (location != null) {
                my_location = location.getLatitude() + ", " + location.getLongitude();
            }
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        my_location = location.getLatitude() + ", " + location.getLongitude();
        locationManager.removeUpdates(this);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 101) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                setLocationManager();
            }
        }
    }



    public void showTimePickerDialog(View v) {
        TimePickerDialog dialog = new TimePickerDialog(this, timeSetListener, hour, minute, DateFormat.is24HourFormat(this));
        dialog.show();
    }
    private TimePickerDialog.OnTimeSetListener timeSetListener = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            time = String.format(Locale.getDefault(), "%02d:%02d", hourOfDay, minute);
            confirm_date.setText("זמן פעולה:" + time + "לחצו עבור לשנות");
        }
    };
    public void func_expand_cv(){
        getDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builderCustomised = new AlertDialog.Builder(DesignSportActivity.this);
                LayoutInflater inflater = getLayoutInflater();
                Calendar currentDate = Calendar.getInstance();
                int year = currentDate.get(Calendar.YEAR);
                int month = currentDate.get(Calendar.MONTH);
                int day = currentDate.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(DesignSportActivity.this, new
                        DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int selectedYear, int selectedMonth, int selectedDay) {
                                Calendar calendar = Calendar.getInstance();
                                calendar.set(Calendar.YEAR, selectedYear);
                                calendar.set(Calendar.MONTH, selectedMonth);
                                calendar.set(Calendar.DAY_OF_MONTH, selectedDay);
                                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                                String format_date = dateFormat.format(calendar.getTime());
                                date = format_date;
                                getDate.setText(date + "לחצו עבור לשנות את תאריך:");
                                formattedDate = date;
                            }
                        }, year, month, day);
                datePickerDialog.show();
            }
        });

    }
    public void func_createSportActivity(){
        create_sport_activity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                temp ="";
                if (check_variables() == false){
                    if(title.isEmpty()){
                        message ="כותרת חסרה, צריך למלא חלק זה";
                        temp+=message + "\n";
                    } if(category.isEmpty()){
                        message="קטגוריה חסרה, צריך למלא חלק זה";
                        temp+=message + "\n";
                    }
                    if (time.isEmpty()) {
                        message ="זמן פעולה חסר , צריך למלא חלק זה";
                        temp+=message + "\n";
                    }
                    if (description.isEmpty()) {
                        message="תיאור פעולה חסר, ץריך למלא חלק זה";
                        temp+=message + "\n";
                    }
                    if (formattedDate.isEmpty()) {
                        message="תאריך פעולה חסר, צריך למלא חלק זה ";
                        temp+=message + "\n";
                    }
                    new AlertDialog.Builder(DesignSportActivity.this)
                            .setTitle("פרטים חסרים")
                            .setMessage(temp)
                            .setPositiveButton("אישור", null)
                            .show();
                } else{
                    new AlertDialog.Builder(DesignSportActivity.this)
                            .setMessage("פעולה נוצרה בהצלחה")
                            .setPositiveButton("אישור", null)
                            .show();                    AppDatabase.databaseWriteExecutor.execute(new Runnable() {
                        @Override
                        public void run() {
                            sportingActivityClass = new SportingActivityClass(title, category, selected_customer, time, description, my_location, false, formattedDate);
                            selected_customer.addSportingActivity(sportingActivityClass);
                            sportingActivityClassDao.insert(sportingActivityClass);
                        }
                    });
                }
            }
        });
        editText_title.setText("");
        editText_sport_act_desc.setText("");
    }
    public boolean check_variables(){
        if(date == null || time.isEmpty() || editText_sport_act_desc.getText().toString().isEmpty() || editText_title.getText().toString().isEmpty()){
            return false;
        } else{
            description = editText_sport_act_desc.getText().toString();
            title = editText_title.getText().toString();
            return true;
        }
    }

    public void getDate(){
        confirm_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (date != null) {
                    showTimePickerDialog(view);
                } else {
                    Toast.makeText(DesignSportActivity.this, "אנא בחרו תאריך", Toast.LENGTH_SHORT).show();
                }
            }
        });
        timeSetListener = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                time = String.format(Locale.getDefault(), "%02d:%02d", hourOfDay, minute);
                confirm_date.setText("זמן פעולה: " + time + " לחצו עבור לשנות");
                String selectedDateTime = "Selected date and time: " + formattedDate + " " + time;
                //Toast.makeText(DesignSportActivity.this, selectedDateTime, Toast.LENGTH_LONG).show();
            }
        };
    }
    public void func_view_sport_activities() {
        btn_to_see_sport_activities.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent I = new Intent(DesignSportActivity.this, MySportingActivitiesActivity.class);
                I.putExtra("customer", selected_customer);
                startActivity(I);
            }
        });
    }

    public void receiveCustomerFromDesignSportActivity() {
        Intent intent = getIntent();
        Customer customer = (Customer) intent.getSerializableExtra("customer");
    }






    public void init(){
        getDate = findViewById(R.id.getDate);
        create_sport_activity = findViewById(R.id.button_add_sport);
        category = getIntent().getStringExtra("sport");
        setTitle(category);
        editText_title = findViewById(R.id.sport_act_title);
        editText_sport_act_desc = findViewById(R.id.EditTxt_act_desc);
        app_db = AppDatabase.getDatabase(this);
        customerDao = app_db.customerDAO();
        sportingActivityClassDao = app_db.SportingActivityClassDao();
        view_sport_activities = findViewById(R.id.view_sport_activities);
        btn_to_see_sport_activities = findViewById(R.id.btn_to_see_sport_activities);
        Intent intent = getIntent();
        selected_customer = (Customer) intent.getSerializableExtra("customer");
        info_sport_category = findViewById(R.id.txtView_sport_act_info);
        info_sport_category.setText("פעולת ה " + category + " " + selected_customer.getName());
        //loadCustomerFromDatabase(selectedCustomerName);
        get_location = findViewById(R.id.get_location);
        calendar = Calendar.getInstance();
        confirm_date = findViewById(R.id.button_confirm_date);
        hour = calendar.get(Calendar.HOUR_OF_DAY);
        minute = calendar.get(Calendar.MINUTE);
    }
   /* private void loadCustomerFromDatabase(String customerName) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Customer customer = customerDao.getCustomersByNameNoLD(customerName);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        onCustomerLoaded(customer);
                    }
                });
            }
        }).start();
    }

    private void onCustomerLoaded(Customer customer) {
        selected_customer = customer;
        info_sport_category.setText("פעולת ה"  + category + "של"+selected_customer.getName() );
        Toast.makeText(DesignSportActivity.this, "" + customer.getName() + " ", Toast.LENGTH_SHORT).show();
    }*/



}

  /* public void func_expand_calendar(){
        calendarView.setOnClickListener(new View.OnClickListener() {
            boolean isExpanded = false;
            @Override
            public void onClick(View v) {
                if (!isExpanded) {
                    ViewGroup.LayoutParams expandedLayoutParams = new ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT // set to MATCH_PARENT
                    );
                    calendarView.setLayoutParams(expandedLayoutParams);
                } else {
                    calendarView.setLayoutParams(originalLayoutParams);
                }
                isExpanded = !isExpanded;
            }
        });
    }*/