package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class CreateSportActivity extends AppCompatActivity {
    private ImageView football_imgView;
    private ImageView tennis_imgView;
    private ImageView basketball_imgView;
    private ImageView volleyball_imgView;
    private CustomerDao customerDao;
    private AppDatabase app_db;
    private Customer selected_customer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_sport);
        init();
        func_volleyball_clicked();
        func_basketball_clicked();
        func_football_clicked();
        func_tennis_clicked();
    }

    public void init(){
        football_imgView = findViewById(R.id.football_imgView);
        basketball_imgView= findViewById(R.id.basketball_imgView);
        volleyball_imgView = findViewById(R.id.volleyball_imgVIew);
        tennis_imgView = findViewById(R.id.tennis_imgView);
        //selected_customer = (Customer) getIntent().getSerializableExtra("customer");
        /*new Thread(new Runnable() {
            @Override
            public void run() {
                selected_customer = customerDao.getLatestCustomer();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if(selected_customer != null){

                        }
                    }
                });
            }
        }).start()*///        Toast.makeText(CreateSportActivityActivity.this, "helo " + selected_customer.getName() + "welcom! ", Toast.LENGTH_SHORT).show();
        app_db = AppDatabase.getDatabase(this);
        customerDao = app_db.customerDAO();
        int expandedHeight = 500;
        Intent intent = getIntent();
        selected_customer = (Customer) intent.getSerializableExtra("customer");
        /*new Thread(new Runnable() {
            @Override
            public void run() {
                customer = customerDao.getCustomerById(Integer.parseInt(customer_id)); // use customer_id instead of intentExtra
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(CreateSportActivityActivity.this, customer.name + "" + customer.getName(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }).start();*/
    }

    public void func_football_clicked(){
        football_imgView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CreateSportActivity.this, DesignSportActivity.class);
                intent.putExtra("sport", "football");
                intent.putExtra("customer", selected_customer);
                startActivity(intent);
            }
        });
    }

    public void func_basketball_clicked(){
        basketball_imgView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CreateSportActivity.this, DesignSportActivity.class);
                intent.putExtra("sport", "basketball");
                intent.putExtra("customer", selected_customer);
                startActivity(intent);
            }
        });
    }

    public void func_tennis_clicked(){
        tennis_imgView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CreateSportActivity.this, DesignSportActivity.class);
                intent.putExtra("sport", "tennis");
                intent.putExtra("customer", selected_customer);
                startActivity(intent);
            }
        });
    }

    public void func_volleyball_clicked(){
        volleyball_imgView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CreateSportActivity.this, DesignSportActivity.class);
                intent.putExtra("sport", "volleyball");
                intent.putExtra("customer", selected_customer);
                startActivity(intent);
            }
        });
    }
}