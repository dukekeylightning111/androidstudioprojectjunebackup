package com.example.myapplication;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import java.io.Serializable;

@Entity(tableName = "SportingActivityClass")
@TypeConverters(CustomerTypeConverter.class)
public class SportingActivityClass implements Serializable {

    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "category")
    private String category;

    @ColumnInfo(name = "description")
    private String description;
    @ColumnInfo(name = "date")
    private String date;

    @ColumnInfo(name = "customer")
    private Customer customer;
    @ColumnInfo(name= "customerId")
    private Integer customerId;

    @ColumnInfo(name = "time")
    private String time;

    @ColumnInfo(name = "location")
    private String location;
    @ColumnInfo(name = "activityTitle")
    private String title;

    @ColumnInfo(name = "private")
    private boolean isPrivate;

    public SportingActivityClass(String title, String category, Customer customer, String time, String description,String location, boolean isPrivate,String date) {
        this.title = title;
        this.category = category;
        this.customer = customer;
        this.customerId=customer.getId();
        this.time = time;
        this.description = description;
        this.location = location;
        this.isPrivate = isPrivate;
        this.date = date;
    }



    public Integer getCustomerId(){
        return customerId;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }


    public int getId() {
        return id;
    }
    public String getTitle(){
        return this.title;
    }
    public void setDescription(String description){
        this.description= description;
    }
    public String getDescription() {
        return description;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Customer getCustomer() {
        return customer;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getLocation() {
        return location;
    } public String getDate() {
        return date;
    }

    public void setLocation(String location) {
        this.location = location;
    }
    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isPrivate() {
        return isPrivate;
    }

    public void setPrivate(boolean isPrivate) {
        this.isPrivate = isPrivate;
    }


}