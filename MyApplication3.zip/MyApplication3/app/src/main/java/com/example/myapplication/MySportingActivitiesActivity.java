package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class MySportingActivitiesActivity extends AppCompatActivity {
    private Button btn_to_see_sport_activities;
    private AppDatabase app_db;
    private CustomerDao customerDao;
    private FloatingActionButton myFAB;
    private Customer customer;
    private SportingActivityAdapter adapter;
    private TextView customer_name;
    private SportingActivityClassDao sportingActivityClassDao;
    private RecyclerView recyclerView;
    private Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_sporting_activities);
        Intent intent = getIntent();
        init();
        customer = (Customer) intent.getSerializableExtra("customer");
        customer_name.setText("AASDAOIjdauihdoasiudhoasd yes");
        customer_name.setText("הפעולות של " + customer.getName());
        recyclerView = findViewById(R.id.sporting_activity_recycler_view);
        func_view_sport_activities();
        func_create_sport_activity();
    }
    public void func_create_sport_activity(){
        myFAB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent createSportIntent = new Intent(context, CreateSportActivity.class);
                createSportIntent.putExtra("customer", customer);
                startActivity(createSportIntent);
            }
        });
    }
    public void init() {
        app_db = AppDatabase.getDatabase(this);
        customerDao = app_db.customerDAO();
        sportingActivityClassDao = app_db.SportingActivityClassDao();
        customer_name = findViewById(R.id.customer_name);
        myFAB = findViewById(R.id.myFAB);
        context = getApplicationContext();

    }

    public void func_view_sport_activities() {
        // Use the AsyncTask to retrieve the sport activities
        new AsyncTask<Void, Void, List<SportingActivityClass>>() {
            @Override
            protected List<SportingActivityClass> doInBackground(Void... voids) {
                return customer.getSportingActivityClasses();
            }

            @Override
            protected void onPostExecute(List<SportingActivityClass> sportingActivities) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        customer = customerDao.getLatestCustomer();
                    }
                }).start();
                adapter = new SportingActivityAdapter(customer);
                adapter.setSportingActivities(sportingActivities);
                recyclerView.setAdapter(adapter);
                recyclerView.setLayoutManager(new LinearLayoutManager(MySportingActivitiesActivity.this));
                SwipeToDelete swipeToDelete = new SwipeToDelete(adapter, app_db, MySportingActivitiesActivity.this);
                ItemTouchHelper itemTouchHelper = new ItemTouchHelper(swipeToDelete);
                itemTouchHelper.attachToRecyclerView(recyclerView);
                recyclerView.setVisibility(View.VISIBLE);
            }
        }.execute();
    }
}