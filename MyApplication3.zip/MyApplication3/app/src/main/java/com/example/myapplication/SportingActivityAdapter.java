package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SportingActivityAdapter extends RecyclerView.Adapter<SportingActivityAdapter.ViewHolder> {
    private List<SportingActivityClass> sportingActivities;

    public SportingActivityAdapter(Customer customer) {
        this.sportingActivities = customer.getSportingActivityClasses();
    }

    public void setSportingActivities(List<SportingActivityClass> sportingActivities) {
        this.sportingActivities = sportingActivities;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.sporting_activity_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bind(sportingActivities.get(position));
    }

    @Override
    public int getItemCount() {
        return sportingActivities.size();
    }

    public SportingActivityClass getSportingActivityAtPosition(int position) {
        return sportingActivities.get(position);
    }


    public void removeSportingActivity(int position) {
        this.sportingActivities.remove(position);
        notifyItemRemoved(position);
    }

    public void deleteSportingActivity(SportingActivityClass sportingActivityClass, SportingActivityClassDao sportingActivityClassDao) {
        sportingActivityClassDao.delete(sportingActivityClass);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView nameTextView;
        private TextView categoryTextView;
        private TextView timeTextView;
        private TextView locationTextView;
        private TextView adminCustomerTextView;
        private TextView activityDescTextView;
        private TextView activityDateTextView;
        private ImageView imageViewCategory;

        public ViewHolder(View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.sport_activity_name);
            categoryTextView = itemView.findViewById(R.id.sport_act_cat);
            timeTextView = itemView.findViewById(R.id.sport_activity_time);
            locationTextView = itemView.findViewById(R.id.sport_activity_location);
            adminCustomerTextView = itemView.findViewById(R.id.customerName);
            activityDescTextView = itemView.findViewById(R.id.act_desc);
            imageViewCategory = itemView.findViewById(R.id.imageViewCategory);
            //activityDateTextView = itemView.findViewById(R.id.act_date);
        }

        public void bind(@NonNull SportingActivityClass sportingActivity) {
            String name = sportingActivity.getTitle();
            String time = sportingActivity.getTime();
            String sport_act_cat = sportingActivity.getCategory();
            String location = sportingActivity.getLocation();
            String description = activityDescTextView.getText().toString() + " " + String.valueOf(sportingActivity.getDescription());
            String activityId = " sport activity id: " + String.valueOf(sportingActivity.getId());
            if (sportingActivity.getCustomer() == null) {
                adminCustomerTextView.setText("failed :(");
                sportingActivity.getCustomer().setName("testign");
            } else {
                String customerName = sportingActivity.getCustomer().getName();
                if (customerName != null) {
                    adminCustomerTextView.setText("name:" + customerName);
                }
            }
            String desc_new_lines= activityDescTextView.getText().toString();
            desc_new_lines = description.replaceAll("\\.", "\n"); // replace all '.' with '\n'
            activityDescTextView.setText(desc_new_lines);
            nameTextView.setText(name + " " + activityId);
            timeTextView.setText(String.valueOf(sportingActivity.getDate()) + " " + time);
            categoryTextView.setText(sport_act_cat);
            locationTextView.setText(location);
            activityDescTextView.setText(description);
          /*  if(sport_act_cat.toString().toLowerCase() == "football"){
                imageViewCategory.setImageResource(R.drawable.football);
            }
            if(sport_act_cat.toString().toLowerCase() == "basketball"){
                imageViewCategory.setImageResource(R.drawable.basketball);
            }
            if(sport_act_cat.toString().toLowerCase() == "tennis"){
                imageViewCategory.setImageResource(R.drawable.tennis);
            }
            if(sport_act_cat.toString().toLowerCase() == "volleyball"){
                imageViewCategory.setImageResource(R.drawable.voleyball);
            }*/
        }
    }
}