package com.example.myapplication;

import androidx.room.TypeConverter;

class CustomerTypeConverter {

    @TypeConverter
    public static Customer fromString(String value) {
        return new Customer(value);
    }

    @TypeConverter
    public static String customerToString(Customer customer) {
        return customer.toString();
    }

}